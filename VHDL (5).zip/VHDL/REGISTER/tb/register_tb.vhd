
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity register_tb is
end register_tb;

architecture architecture_tb of register_tb is
    signal clk_s        : STD_LOGIC := '0';
    signal rst_n_s      : STD_LOGIC := '0';
    signal data_s       : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
    signal wr_enable_s  : STD_LOGIC := '0';
    signal read_addr_s  : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal q_s          : STD_LOGIC_VECTOR(7 downto 0);

    signal idle_s        : STD_LOGIC :='0';
    signal r_s        : STD_LOGIC :='0'; 
    signal wr_s        : STD_LOGIC :='0';

    constant clock_period : time := 10 ns; -- Adjust the clock period as needed

    signal stop_simulation : boolean := false;
    
	component register_e
        port(
             clk_i        : IN STD_LOGIC;
             rst_n_i      : IN STD_LOGIC;
             idle_i       : IN STD_LOGIC;
             wr_i         : IN STD_LOGIC;
             r_i          : IN STD_LOGIC;
             data_i       : IN STD_LOGIC_VECTOR(7 downto 0);
             read_addr_i  : IN STD_LOGIC_VECTOR(3 downto 0);
             q_o          : OUT STD_LOGIC_VECTOR(7 downto 0)
            );
     	end component;
     
     	component register_fsm_e   
        Port ( 
              clk_i        : IN STD_LOGIC;
              rst_n_i      : IN STD_LOGIC;
              wr_enable_i  : IN STD_LOGIC;
              read_addr_i  : IN STD_LOGIC_VECTOR(3 downto 0);
              idle_o       : OUT STD_LOGIC;
              wr_o         : OUT STD_LOGIC;
              r_o          : OUT STD_LOGIC
           );
    	end component;
begin
   
	register_inst : register_e
        port map (
            clk_i       => clk_s,
            rst_n_i     => rst_n_s,
            idle_i      => idle_s,
            wr_i        => wr_s,
            r_i         => r_s,
            data_i      => data_s,
            read_addr_i => read_addr_s,
            q_o         => q_s
        );

    	fsm_inst : register_fsm_e
        port map (
            clk_i        => clk_s,
            rst_n_i      => rst_n_s,
            wr_enable_i  => wr_enable_s,
            read_addr_i  => read_addr_s,
            idle_o       => idle_s,
            wr_o         => wr_s,
            r_o          => r_s
        );



    -- Clock process
    clk_i_process: process
    begin
        while not stop_simulation loop
            clk_s <= '0';
            wait for clock_period / 2;
            clk_s <= '1';
            wait for clock_period / 2;
        end loop;
        wait;
    end process;

    -- Stimulus process
    stimulus_process: process
    begin
        -- Apply reset
        rst_n_s <= '0';
        wait for 10 ns;
        rst_n_s <= '1';
	    wait for 10 ns;
        -- Write to register 2
        wr_enable_s <= '1';
	    wait until clk_s = '1';
        data_s <= "00101100";  -- Address: 0010, Data: 1100
        wait for 10 ns;
        wr_enable_s <= '0';
	wait for 10 ns;
        -- Read from register 2
        read_addr_s <= "0010";
        wait for 10 ns;

        -- Check the output
        assert q_s = "1100"
            report "Test failed: Output doesn't match expected value."
            severity error;
	wait for 10 ns;
        stop_simulation <= true;
        wait;
    end process;

end architecture_tb;