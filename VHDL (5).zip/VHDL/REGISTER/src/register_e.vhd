library IEEE;
use IEEE.STD_LOGIC_1164.ALL;



entity register_e is
    Port ( clk_i        : IN STD_LOGIC;
           rst_n_i      : IN STD_LOGIC;
           idle_i       : IN STD_LOGIC;
           wr_i         : IN STD_LOGIC;
           r_i          : IN STD_LOGIC;
           data_i       : IN STD_LOGIC_VECTOR(7 downto 0);
           read_addr_i  : IN STD_LOGIC_VECTOR(3 downto 0);
           q_o          : OUT STD_LOGIC_VECTOR(7 downto 0);
           dv_o         : out STD_LOGIC
    );
end register_e;

