library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


entity register_fsm_e is
    Port ( 
           clk_i        : IN STD_LOGIC;
           rst_n_i      : IN STD_LOGIC;
           wr_enable_i  : IN STD_LOGIC;
           read_addr_i  : IN STD_LOGIC_VECTOR(3 downto 0);
           idle_o       : OUT STD_LOGIC;
           wr_o         : OUT STD_LOGIC;
           r_o          : OUT STD_LOGIC
          );
end register_fsm_e;




