architecture register_a of register_e is
    
	signal reg_01 : STD_LOGIC_VECTOR (7 downto 0);
	signal reg_02 : STD_LOGIC_VECTOR (7 downto 0);
	signal reg_03 : STD_LOGIC_VECTOR (7 downto 0);
	signal reg_04 : STD_LOGIC_VECTOR (7 downto 0);
	signal reg_05 : STD_LOGIC_VECTOR (7 downto 0);
	signal reg_06 : STD_LOGIC_VECTOR (7 downto 0);
	signal reg_07 : STD_LOGIC_VECTOR (7 downto 0);
	signal reg_08 : STD_LOGIC_VECTOR (7 downto 0);

begin
    process(idle_i,wr_i,r_i,clk_i,rst_n_i)
    begin
	if rst_n_i = '0' then
            reg_01   <= (others => '0');
            reg_02   <= (others => '0');
            reg_03   <= (others => '0');
            reg_04   <= (others => '0');
            reg_05   <= (others => '0');
            reg_06   <= (others => '0');
            reg_07   <= (others => '0');
            reg_08   <= (others => '0');
            q_o <= (others => '0');
            dv_o <= '0';
	elsif clk_i'event and clk_i = '1' then
            if idle_i = '1' and wr_i = '0' and r_i ='0' then
            elsif idle_i = '0' and wr_i = '1' and r_i ='0' then
                if data_i(7 downto 4) = "0001" then
			reg_01 <= data_i;
                elsif data_i(7 downto 4) = "0010" then
			reg_02 <= data_i;
                elsif data_i(7 downto 4) = "0011" then
			reg_03 <= data_i;
                elsif data_i(7 downto 4) = "0100" then
			reg_04 <= data_i;
                elsif data_i(7 downto 4) = "0101" then
			reg_05 <= data_i;
                elsif data_i(7 downto 4) = "0110" then
			reg_06 <= data_i;
                elsif data_i(7 downto 4) = "0111" then
			reg_07 <= data_i;
                elsif data_i(7 downto 4) = "1000" then
			reg_08 <= data_i;
			dv_o <= '1';
	        end if;
            elsif idle_i = '0' and wr_i = '0' and r_i ='1' then
                if data_i(7 downto 4) = "0001" then
			q_o <= reg_01;
                elsif data_i(7 downto 4) = "0010" then
			q_o <= reg_02;
                elsif data_i(7 downto 4) = "0011" then
			q_o <= reg_03;
                elsif data_i(7 downto 4) = "0100" then
			q_o <= reg_04;
                elsif data_i(7 downto 4) = "0101" then
			q_o <= reg_05;
                elsif data_i(7 downto 4) = "0110" then
			q_o <= reg_06;
                elsif data_i(7 downto 4) = "0111" then
			q_o <= reg_07;
                elsif data_i(7 downto 4) = "1000" then
			q_o <= reg_08;
		end if;
            end if;
	end if;

    end process;
end register_a;