
architecture register_top_a of register_top_e is

	signal idle_s : STD_LOGIC;
	signal wr_s   : STD_LOGIC;
	signal r_s    : STD_LOGIC;
    signal dv_s    : STD_LOGIC;
	
	component register_e
        port(
             clk_i        : IN STD_LOGIC;
             rst_n_i      : IN STD_LOGIC;
             idle_i       : IN STD_LOGIC;
             wr_i         : IN STD_LOGIC;
             r_i          : IN STD_LOGIC;
             data_i       : IN STD_LOGIC_VECTOR(7 downto 0);
             read_addr_i  : IN STD_LOGIC_VECTOR(3 downto 0);
             q_o          : OUT STD_LOGIC_VECTOR(7 downto 0);
             dv_o         : out STD_LOGIC
            );
     end component;
     
     component register_fsm_e   
        Port ( 
              clk_i        : IN STD_LOGIC;
              rst_n_i      : IN STD_LOGIC;
              wr_enable_i  : IN STD_LOGIC;
              read_addr_i  : IN STD_LOGIC_VECTOR(3 downto 0);
              idle_o       : OUT STD_LOGIC;
              wr_o         : OUT STD_LOGIC;
              r_o          : OUT STD_LOGIC
           );
    end component;
    
begin
        register_inst : register_e
        port map (
            clk_i       => clk_i,
            rst_n_i     => rst_n_i,
            idle_i      => idle_s,
            wr_i        => wr_s,
            r_i         => r_s,
            data_i      => data_i,
            read_addr_i => read_addr_i,
            q_o         => q_o,
            dv_o        => dv_s
        );

    fsm_inst :register_fsm_e
        port map (
            clk_i        => clk_i,
            rst_n_i      => rst_n_i,
            wr_enable_i  => wr_enable_i,
            read_addr_i  => read_addr_i,
            idle_o       => idle_s,
            wr_o         => wr_s,
            r_o          => r_s
        );
    dv_o <= dv_s;
end register_top_a;