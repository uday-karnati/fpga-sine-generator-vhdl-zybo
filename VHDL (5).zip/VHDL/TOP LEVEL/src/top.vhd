library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity top_level is
    Port (
        -- Clock and Reset
        clk_i        : in STD_LOGIC;
        rst_n_i      : in STD_LOGIC;

        -- VGA Module
        h_sync_o     : out STD_LOGIC;
        v_sync_o     : out STD_LOGIC;
        red_o        : out STD_LOGIC_VECTOR(2 downto 0);
        blue_o       : out STD_LOGIC_VECTOR(2 downto 0);
        green_o      : out STD_LOGIC_VECTOR(2 downto 0);

        -- UART TX Module
        tx_dv_o      : out STD_LOGIC;
        tx_o         : out STD_LOGIC;

        -- UART RX Module
        d_rx_i       : in STD_LOGIC
    );
end top_level;

architecture Behavioral of top_level is

    signal d_rx_reg : STD_LOGIC_VECTOR(0 to 7);
    signal reg_dv_s : std_logic;

    component register_top_e is
        Port (
            clk_i       : in STD_LOGIC;
            rst_n_i     : in STD_LOGIC;
            wr_enable_i : in STD_LOGIC;
            read_addr_i : in STD_LOGIC_VECTOR(3 downto 0);
            data_i      : in STD_LOGIC_VECTOR(7 downto 0);
            q_o         : out STD_LOGIC_VECTOR(7 downto 0);
            dv_o         : out STD_LOGIC
        );
    end component;

    component vga_e is
        Port (
            clk_i     : in  std_logic;
            rst_n_i   : in  std_logic;
            sine_i    : in  std_logic_vector (7 downto 0);
            h_sync_o  : out std_logic;
            v_sync_o  : out std_logic;
            red_o     : out std_logic_vector (2 downto 0);
            blue_o    : out std_logic_vector (2 downto 0);
            green_o   : out std_logic_vector (2 downto 0)
        );
    end component;

    component uart_tx_top is
        Port (
            clk_i      : in STD_LOGIC;
            rst_n_i    : in STD_LOGIC;
            d_i        : in STD_LOGIC_VECTOR (0 to 7);
            d_o        : out STD_LOGIC;
            tx_start_i : in std_logic;
            tx_dv_o    : out std_logic
        );
    end component;

    component uart_rx_top is
        Port (
            clk_i   : in STD_LOGIC;
            rst_n_i : in STD_LOGIC;
            d_i     : in STD_LOGIC;
            d_o     : out STD_LOGIC_VECTOR (0 to 7);
            rx_dv   : out std_logic
        );
    end component;

    component sincounter is
        Port (
            clk       : in std_logic;
            rst       : in std_logic;
            en_i      : in std_logic;
            reg_i     : in std_logic_vector(7 downto 0);
            read_add_o: out std_logic_vector(3 downto 0);
            sin_x     : out std_logic_vector(7 downto 0);
            tx_start_o: out std_logic
        );
    end component;

    signal h_sync, v_sync : STD_LOGIC;
    
    signal q_s : std_logic_vector(7 downto 0);
    signal read_addr_s : std_logic_vector(3 downto 0);
    
    signal red, blue, green : STD_LOGIC_VECTOR(2 downto 0);

    signal tx_dv_s, tx_o_s, tx_start_s : std_logic;
    signal rx_dv_s: std_logic;

    signal sin_x_out, sin_y_out : std_logic_vector(7 downto 0);

begin

    -- Instantiate components

    register_instance : register_top_e
        port map (
            clk_i       => clk_i,
            rst_n_i     => rst_n_i,
            wr_enable_i => rx_dv_s,
            read_addr_i => read_addr_s,
            data_i      => d_rx_reg,
            q_o         => q_s,
            dv_o        => reg_dv_s
        );

    vga_instance : vga_e
        port map (
            clk_i   => clk_i,
            rst_n_i => rst_n_i,
            sine_i  => sin_x_out,
            h_sync_o => h_sync_o,
            v_sync_o => v_sync_o,
            red_o   => red_o,
            blue_o  => blue_o,
            green_o => green_o
        );

    uart_tx_instance : uart_tx_top
        port map (
            clk_i      => clk_i,
            rst_n_i    => rst_n_i,
            d_i        => sin_x_out,
            d_o        => tx_o_s,
            tx_start_i => tx_start_s,
            tx_dv_o    => tx_dv_s
        );

    uart_rx_instance : uart_rx_top
        port map (
            clk_i   => clk_i,
            rst_n_i => rst_n_i,
            d_i     => d_rx_i,
            d_o     => d_rx_reg,
            rx_dv   => rx_dv_s
        );

    sincounter_instance : sincounter
        port map (
            clk      => clk_i,
            rst      => rst_n_i,
            en_i     => reg_dv_s,
            reg_i    => q_s,
            read_add_o => read_addr_s,
            sin_x    => sin_x_out,
            tx_start_o => tx_start_s
        );

    tx_o <= tx_o_s;
    tx_dv_o <= tx_dv_s;

end Behavioral;
