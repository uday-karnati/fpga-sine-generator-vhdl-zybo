library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity toptb is
end toptb;

architecture SIM of toptb is
    -- Constants
    constant CLK_PERIOD : time := 83 ns;  -- Define your clock period

    -- Signals
    signal clk_s     : std_logic := '0';
    signal rst_n_s   : std_logic := '0';
    signal d_rx_s    : std_logic := '0';  -- Provide appropriate values for d_rx_i
    -- Declare other signals for inputs and expected outputs
    signal h_sync_s  : std_logic := '0';
    signal v_sync_s  : std_logic := '0';

    signal red_s    : std_logic_vector (2 downto 0) := "000";
    signal blue_s   : std_logic_vector (2 downto 0) := "000";
    signal green_s  : std_logic_vector (2 downto 0) := "000";

    signal tx_dv_s    : std_logic := '0';
    signal tx_d_s    : std_logic := '0';

    signal dum_d_s   : std_logic_vector (0 to 7) := X"67";

    signal rx_d_o_s  : std_logic_vector (0 to 7);
    signal rx_dv_s    : std_logic := '0';

    signal br_s :std_logic;
begin
    
    uut_uart_rx : entity work.uart_rx_top
                  port map ( 
           	  	clk_i   =>clk_s,
                  	rst_n_i =>rst_n_s,
                  	d_i     =>d_rx_s,
                  	d_o     =>rx_d_o_s,
                   	rx_dv   =>rx_dv_s,	
			br_g_o  =>br_s
                  );


    clk_s <= not clk_s after CLK_PERIOD/2;


    -- Stimulus process
    process
    begin
        -- Initialize signals
        rst_n_s <= '0';
        wait for 10 ns;
        rst_n_s <= '1';
        wait for 10 ns;

	d_rx_s <= '1';
	wait until br_s = '1';
	for i in 0 to 7 loop
		d_rx_s <= dum_d_s(i);
		wait until br_s = '1';
	end loop;
	d_rx_s <= '0';
	wait for 300 ns;
  
        wait;
    end process;
    --assert rising_edge(h_sync_s) report "Error: Unexpected rising edge of h_sync" severity error;

    -- Assertion for checking the falling edge of the v_sync signal
    --assert falling_edge(v_sync_s) report "Error: Unexpected falling edge of v_sync" severity error;

    -- Assertion for checking if red, green, and blue signals are within valid range (0 to 7)
    --assert red_s >= "000" and red_s <= "111"
    --report "Error: Red signal out of valid range" severity error;
    --assert green_s >= "000" and green_s <= "111"
    --report "Error: Green signal out of valid range" severity error;
    --assert blue_s >= "000" and blue_s <= "111"
    --report "Error: Blue signal out of valid range" severity error;

    -- Assertion for checking if tx_dv signal is asserted when tx_o is valid
    --assert (tx_d_s = '1') = (tx_dv_s = '1')
    --report "Error: tx_dv assertion failed" severity error;

end SIM;
