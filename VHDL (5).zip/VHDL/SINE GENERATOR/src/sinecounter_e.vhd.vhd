library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity sincounter_e is 
    port (
        clk       : in std_logic;
        rst       : in std_logic;
        en_i      : in std_logic;
        reg_i     : in std_logic_vector(7 downto 0);
        read_add_o: out std_logic_vector(3 downto 0);
        tx_start_o: out std_logic;
        sin_x     : out std_logic_vector(7 downto 0)
    );
end sincounter_e;

