library IEEE;
use IEEE.STD_LOGIC_1164.ALL;    
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.NUMERIC_STD.ALL;

architecture behavioral of sincounter_a is
    signal counter_s    : std_logic_vector(11 downto 0);
    signal max_count    : std_logic_vector(11 downto 0);
    signal coef_count   : std_logic_vector(3 downto 0);
    signal sin_s_x      : std_logic_vector(7 downto 0);
    signal quad_count   : std_logic_vector(3 downto 0);
    signal counter_freq : std_logic_vector(11 downto 0);
    signal totalquad    : std_logic_vector(3 downto 0);
    signal totalfreq    : std_logic_vector(11 downto 0);
    signal totalcoef    : std_logic_vector(3 downto 0);
    type T_STATE is (IDLE, FIRST, SECOND, THIRD);
    signal main_state   : T_STATE;

begin


process(clk, rst)
begin
    if rising_edge(clk) then
        if rst = '0' then
            main_state <= IDLE;
            
        else
            case main_state is
                when IDLE =>
                    if en_i = '1' then
                        main_state <= FIRST;
                        tx_start_o <= '0';
                    else
                        main_state <= IDLE;
                    end if;
                
                when FIRST =>
                    if quad_count = totalquad then
                        quad_count <= (others => '0');
                        main_state <= IDLE;
                    else
                        main_state <= SECOND;
                        quad_count <= quad_count + 1;
                    end if;
                
                when SECOND =>
                    if coef_count = totalcoef then
                        coef_count <= (others => '0');
                        main_state <= FIRST;
                    else
                        coef_count <= coef_count + 1;
                        main_state <= THIRD;
                    end if;
                
                when THIRD =>
                    if counter_freq = totalfreq then
                        counter_freq <= (others => '0');
                        main_state <= SECOND;
                    else
                        counter_freq <= counter_freq + 1;
                    end if;
                
                    if quad_count = x"1" then
                        tx_start_o <= '1';
                        case coef_count is
                            when x"1" =>
                                read_add_o <= "0000";
                            when x"2" =>
                                read_add_o <= "0001";
                            when x"3" =>
                                read_add_o <= "0010";
                            when x"4" =>
                                read_add_o <= "0011";
                            when x"5" =>
                                read_add_o <= "0100";
                            when x"6" =>
                                read_add_o <= "0101";
                            when x"7" =>
                                read_add_o <= "0110";
                            when x"8" =>
                                read_add_o <= "0111";
                            when others =>
                                read_add_o <= "0000";
                        end case;
                    end if;
                
                    if quad_count = x"2" then
                        case coef_count is
                            when x"8" =>
                                read_add_o <= "0111";
                            when x"7" =>
                                read_add_o <= "0110";
                            when x"6" =>
                                read_add_o <= "0101";
                            when x"5" =>
                                read_add_o <= "0100";
                            when x"4" =>
                                read_add_o <= "0011";
                            when x"3" =>
                                read_add_o <= "0010";
                            when x"2" =>
                                read_add_o <= "0001";
                            when x"1" =>
                                read_add_o <= "0000";
                            when others =>
                                read_add_o <= "0111";
                        end case;
                    end if;
                
                    if quad_count = x"3" then
                        case coef_count is
                            when x"1" =>
                                read_add_o <= "0000";
                            when x"2" =>
                                read_add_o <= "0001";
                            when x"3" =>
                                read_add_o <= "0010";
                            when x"4" =>
                                read_add_o <= "0011";
                            when x"5" =>
                                read_add_o <= "0100";
                            when x"6" =>
                                read_add_o <= "0101";
                            when x"7" =>
                                read_add_o <= "0110";
                            when x"8" =>
                                read_add_o <= "0111";
                            when others =>
                                read_add_o <= "0000";
                        end case;
                    end if;
                
                    if quad_count = x"4" then
                        case coef_count is
                            when x"8" =>
                                read_add_o <= "0111";
                            when x"7" =>
                                read_add_o <= "0110";
                            when x"6" =>
                                read_add_o <= "0101";
                            when x"5" =>
                                read_add_o <= "0100";
                            when x"4" =>
                                read_add_o <= "0011";
                            when x"3" =>
                                read_add_o <= "0010";
                            when x"2" =>
                                read_add_o <= "0001";
                            when x"1" =>
                                read_add_o <= "0000";
                            when others =>
                                read_add_o <= "0111";
                        end case;
                    end if;
            end case;
        end if;
    end if;
end process;

sin_x <= reg_i;

end behavioral;

