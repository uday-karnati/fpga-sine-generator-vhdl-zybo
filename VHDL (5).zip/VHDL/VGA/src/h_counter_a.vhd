architecture h_counter_a of h_counter_e is

	signal hcount_s : integer;

begin

	reset : process (clk_50hz_i,rst_n_i)
	begin
		if rst_n_i = '1' then
			hcount_s           <= 0;
			hsync_o            <= '0';
			addressable_time_o <= '0';
			en_v_counter_o     <= '0';
		elsif clk_50hz_i'event and clk_50hz_i = '1' then
			if hcount_s < 95 then
				hsync_o            <= '1';
				hcount_s           <= hcount_s + 1;
				en_v_counter_o     <= '0';
			elsif hcount_s >= 95 and hcount_s < 799 then
				hsync_o            <= '0';
				addressable_time_o <= '1';
				hcount_s           <= hcount_s + 1;
			else	
				hsync_o            <= '0';
				addressable_time_o <= '0';
				en_v_counter_o     <= '1';
				hcount_s           <= 0;
			end if;
		end if;
	end process;	

	hcount_o <= hcount_s;

end h_counter_a;