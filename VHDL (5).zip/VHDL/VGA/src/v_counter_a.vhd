architecture v_counter_a of v_counter_e is

	signal vcount_s : integer;

begin

	reset : process (clk_50hz_i,rst_n_i)
	begin
		if rst_n_i = '1' then
			addressable_time_o <= '0';
			vcount_s <= 0;
			vsync_o  <= '0';
		elsif clk_50hz_i'event and clk_50hz_i = '1' then
			if en_v_counter_i = '1' then
				if vcount_s < 2 then
					vsync_o            <= '1';
					vcount_s           <= vcount_s + 1;
				elsif vcount_s >= 2 and vcount_s < 514 then
					vsync_o            <= '0';
					addressable_time_o <= '1';
					vcount_s           <= vcount_s + 1;
				else	
					vsync_o            <= '0';
					addressable_time_o <= '0';
					vcount_s           <=  0;
				end if;
			end if;
		end if;
	end process;	

	vcount_o <= vcount_s;	
	
end v_counter_a;