library ieee;
use ieee.std_logic_1164.all;

entity clk_divider_e is
	generic(
	divider   : integer
	);
	port(
	clk_i   : in  std_logic;
	rst_n_i : in  std_logic;
	clk_o   : out std_logic
	);
end entity;