architecture vga_a of vga_e is

	component v_counter_e
		port(
		clk_50hz_i         : in  std_logic;
		rst_n_i            : in  std_logic;
		en_v_counter_i     : in  std_logic;
		addressable_time_o : out std_logic;
		vsync_o            : out std_logic;
		vcount_o           : out integer
		);
	end component;

	component h_counter_e 
		port(
		clk_50hz_i         : in  std_logic;
		rst_n_i            : in  std_logic;
		en_v_counter_o     : out std_logic;
		addressable_time_o : out std_logic;
		hsync_o            : out std_logic;
		hcount_o           : out integer
		);
	end component;

	component clk_divider_e
		generic(
		divider   : integer
		);
		port(
		clk_i   : in  std_logic;
		rst_n_i : in  std_logic;
		clk_o   : out std_logic
		);
	end component;

	signal clk_50hz_s , en_v_counter_s : std_logic;
	signal addressable_time_v_s , addressable_time_h_s : std_logic;

	signal vsync_s , hsync_s : std_logic;

	signal vcount_s , hcount_s : integer; 

begin
	
	clock_divider  : clk_divider_e
				generic map( divider => 10)
				port    map( clk_i=>clk_i, rst_n_i=>rst_n_i, clk_o=>clk_50hz_s); 
	
	h_counter_comp : h_counter_e port map(clk_50hz_i=>clk_50hz_s, rst_n_i=>rst_n_i, en_v_counter_o=>en_v_counter_s, addressable_time_o=>addressable_time_h_s, hsync_o=>hsync_s, hcount_o=>hcount_s);
	
	v_counter_comp : v_counter_e port map(clk_50hz_i=>clk_50hz_s, rst_n_i=>rst_n_i, en_v_counter_i=>en_v_counter_s, addressable_time_o=>addressable_time_v_s, vsync_o=>vsync_s, vcount_o=>vcount_s);

	set_color : process(clk_50hz_s, rst_n_i)
	begin
		if rst_n_i = '1' then
			red_o   <= "000";
			blue_o  <= "000";
			green_o <= "000";
		elsif clk_50hz_s'event and clk_50hz_s = '1' then
			if addressable_time_h_s = '1' and addressable_time_v_s = '1' then
				if hcount_s = unsigned(sine_i) then
					red_o   <= "111";
					blue_o  <= "111";
					green_o <= "111";	
				else
					red_o   <= "000";
					blue_o  <= "000";
					green_o <= "000";	
				end if;		
			else
				red_o   <= "000";
				blue_o  <= "000";
				green_o <= "000";	
			end if;
		end if;
	end process;

	v_sync_o <= vsync_s;
	h_sync_o <= hsync_s;
	
end vga_a;