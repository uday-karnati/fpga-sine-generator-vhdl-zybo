library ieee;
use ieee.std_logic_1164.all;

entity v_counter_e is
	port(
	clk_50hz_i         : in  std_logic;
	rst_n_i            : in  std_logic;
	en_v_counter_i     : in  std_logic;
	addressable_time_o : out std_logic;
	vsync_o            : out std_logic;
	vcount_o           : out integer
	);
end entity;