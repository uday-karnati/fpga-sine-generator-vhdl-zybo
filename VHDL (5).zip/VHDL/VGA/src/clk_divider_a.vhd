architecture clk_divider_a of clk_divider_e is
	

	signal clk_50hz_s : std_logic;	
	signal counter    : integer;
	
begin
	process (clk_i, rst_n_i)
	begin
		if rst_n_i = '1' then
			counter    <= 0;
			clk_50hz_s <= '0';
		elsif rising_edge(clk_i) then
			if counter = divider - 1 then
				counter <= 0;
				clk_50hz_s <= not clk_50hz_s;
			else
				counter <= counter + 1;
			end if;
		end if;
	end process;
	clk_o <= clk_50hz_s;
end clk_divider_a;