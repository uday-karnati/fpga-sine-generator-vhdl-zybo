library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity vga_e is
	port(
	clk_i     : in  std_logic;
	rst_n_i   : in  std_logic;
	sine_i    : in  std_logic_vector (7 downto 0);
	
	h_sync_o  : out std_logic;
	v_sync_o  : out std_logic;
	red_o     : out std_logic_vector (2 downto 0);
	blue_o    : out std_logic_vector (2 downto 0);
	green_o   : out std_logic_vector (2 downto 0)

	);
end entity;

