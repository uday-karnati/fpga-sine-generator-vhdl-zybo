library ieee;
use ieee.std_logic_1164.all;

entity h_counter_e is
	port(
	clk_50hz_i         : in  std_logic;
	rst_n_i            : in  std_logic;
	en_v_counter_o     : out std_logic;
	addressable_time_o : out std_logic;
	hsync_o            : out std_logic;
	hcount_o           : out integer
	);
end entity;
