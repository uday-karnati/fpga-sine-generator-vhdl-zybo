library ieee;
use ieee.std_logic_1164.all;

entity vga_tb is
	
end entity;

architecture rtl of vga_tb is

	signal clk_s , rst_n_s     : std_logic := '0';

	component v_counter_e
		port(
		clk_50hz_i         : in  std_logic;
		rst_n_i            : in  std_logic;
		en_v_counter_i     : in  std_logic;
		addressable_time_o : out std_logic;
		vsync_o            : out std_logic;
		vcount_o           : out integer
		);
	end component;

	component h_counter_e 
		port(
		clk_50hz_i         : in  std_logic;
		rst_n_i            : in  std_logic;
		en_v_counter_o     : out std_logic;
		addressable_time_o : out std_logic;
		hsync_o            : out std_logic;
		hcount_o           : out integer
		);
	end component;

	component clk_divider_e
		generic(
		divider   : integer
		);
		port(
		clk_i   : in  std_logic;
		rst_n_i : in  std_logic;
		clk_o   : out std_logic
		);
	end component;

	signal clk_50hz_s , en_v_counter_s : std_logic;
	signal addressable_time_v_s , addressable_time_h_s : std_logic;

	signal vsync_s , hsync_s : std_logic;

	signal vcount_s , hcount_s : integer;

begin
	
	clk_s <= not clk_s after 10 ns;
	
	uut_clock_divider  : clk_divider_e
				generic map( divider => 10)
				port    map( clk_i=>clk_s, rst_n_i=>rst_n_s, clk_o=>clk_50hz_s);

	uut_h_counter_comp : h_counter_e port map(clk_50hz_i=>clk_50hz_s, rst_n_i=>rst_n_s, en_v_counter_o=>en_v_counter_s, addressable_time_o=>addressable_time_h_s, hsync_o=>hsync_s, hcount_o=>hcount_s);
	
	uut_v_counter_comp : v_counter_e port map(clk_50hz_i=>clk_50hz_s, rst_n_i=>rst_n_s, en_v_counter_i=>en_v_counter_s, addressable_time_o=>addressable_time_v_s, vsync_o=>vsync_s, vcount_o=>vcount_s);

	test: process 
	begin
		rst_n_s <= '1';
		wait for 10 ns;
		rst_n_s <= '0';
		wait for 10 ns;
		wait;
	end process; 	

end rtl;
