library ieee;
use ieee.std_logic_1164.all;

entity vga_top_tb is
	
end entity;

architecture rtl of vga_top_tb is

	signal clk_s , rst_n_s     : std_logic := '0';

	component vga_e 
		port(
		clk_i     : in  std_logic;
		rst_n_i   : in  std_logic;
		sine_i    : in  std_logic_vector (7 downto 0);
		h_sync_o  : out std_logic;
		v_sync_o  : out std_logic;
		red_o     : out std_logic_vector (2 downto 0);
		blue_o    : out std_logic_vector (2 downto 0);
		green_o   : out std_logic_vector (2 downto 0)
		);
	end component;
	signal vsync_s , hsync_s : std_logic;

	signal red_s , blue_s , green_s : std_logic_vector (2 downto 0);

begin
	
	clk_s <= not clk_s after 10 ns;

	uut: vga_e port map (clk_i=>clk_s, rst_n_i=>rst_n_s, sine_i=>"10101010", h_sync_o=>hsync_s, v_sync_o=>vsync_s, red_o=>red_s, blue_o=>blue_s, green_o=>green_s);

	test: process 
	begin
		rst_n_s <= '1';
		wait for 10 ns;
		rst_n_s <= '0';
		wait for 10 ns;
		wait;
	end process; 	

end rtl;
