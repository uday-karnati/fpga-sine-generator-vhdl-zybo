library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity UART_RX_E is
    port(
        clk_i   : in std_logic;
        rst_i   : IN std_logic;
        br_i      : IN std_logic;
        d_i     : IN std_logic;
        d_o       : OUT std_logic_vector ( 7 downto 0 );
        rx_dv_o   : OUT std_logic
    );
end entity UART_RX_E;


