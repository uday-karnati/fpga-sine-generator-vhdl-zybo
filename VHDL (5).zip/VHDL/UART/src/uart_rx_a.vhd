architecture UART_RX_A of UART_RX_E is
    type U_STATE is 
        (IDLE,START_BIT,RECIEVING,STOP_BIT) ;  
    signal current_state : u_state;
    signal next_state : u_state ;
    
    signal shift_register : std_logic_vector (0 to 7);  
    signal shift_count : integer; 
    
begin
    Next_Stage_Logic : process (current_state,rst_i)
    begin
        if rst_i = '1' then
            next_state    <= IDLE;
        elsif rising_edge(br_i) then
            case current_state is  
            when IDLE =>
                if d_i = '0' then
                    next_state <= RECIEVING;
                elsif d_i = '1' then
                    next_state <= IDLE;
                end if;
            when RECIEVING =>
                if shift_count < 8 then
                    next_state <= RECIEVING;
                else
                    next_state <= STOP_BIT;
                end if;
            when STOP_BIT =>
                next_state <= IDLE;
            when OTHERS =>
                next_state <= IDLE;
        end case ;
        end if;
    end process Next_Stage_Logic;
    
    Output_logic : process (br_i)
    begin
        if rst_i = '1' then
            shift_register <= (others => '0');
            shift_count    <= 0;
            rx_dv_o        <= '0';
        elsif br_i'event and br_i = '1' then
                if current_state = IDLE then
                    rx_dv_o <= '0'; 
                elsif current_state = RECIEVING then   
                    if shift_count < 8 then
			shift_register(shift_count) <= d_i;
                        shift_count <= shift_count + 1;
                    else 
                        shift_count <= 0;
                    end if;
                elsif current_state = STOP_BIT then
                    shift_count <= 0;
                    rx_dv_o     <= '1'; 
                end if;
        end if;
        d_o <= shift_register;
    end process Output_logic;
    
    State_Register : process (rst_i,br_i)
    begin
        if rst_i = '1' then            
            current_state <= IDLE;
        elsif rising_edge(br_i) then
            current_state <= next_state;
        end if ;
    end process State_Register;
    
    
    
end architecture UART_RX_A;