architecture CLK_A of CLK_E is
    signal clk_s : std_logic := '0';
    
    constant clk_period : time := 1000 ms / clk_frequency ;  
    
begin
    clk_s <= not clk_s after clk_period / 2;
    
    clk_o <= clk_s;
end architecture CLK_A;
