library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity CLK_E is
    generic(
        clk_frequency : integer
    );
    port(
        clk_o : out std_logic
    );
end entity CLK_E;
