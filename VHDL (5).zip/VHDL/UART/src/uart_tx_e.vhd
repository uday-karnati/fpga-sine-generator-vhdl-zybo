library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity UART_TX_E is
    port(
        rst_i  : IN std_logic;
        br_i     : IN std_logic;
        d_i    : IN std_logic_vector  (0 to 7);
        tx_start : IN std_logic;
        d_o      : OUT std_logic;
        tx_dv_o  : OUT std_logic
    );
end entity UART_TX_E;

