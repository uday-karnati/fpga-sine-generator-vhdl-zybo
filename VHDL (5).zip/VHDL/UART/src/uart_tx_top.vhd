----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 12/20/2023 11:07:47 PM
-- Design Name: 
-- Module Name: uart_tx_top - uart_tx_top_a
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity uart_tx_top is
    Port ( clk_i      : in STD_LOGIC;
           rst_n_i    : in STD_LOGIC;
           d_i        : in STD_LOGIC_VECTOR (0 to 7);
           d_o        : out STD_LOGIC;
           tx_start_i : in std_logic;
           tx_dv_o    : out std_logic
          );
end uart_tx_top;

architecture uart_tx_top_a of uart_tx_top is
    
    component brg_e 
    generic(
        clk_frequency : integer;
        divisor       : integer
    );
    port(
        clk_n_i : in  std_logic;
        rst_n_i : in  std_logic;
        br_o    : out std_logic
    );
    end component;
    
    component UART_TX_E     
    port(
        rst_i  : IN std_logic;
        br_i     : IN std_logic;
        d_i    : IN std_logic_vector  (0 to 7);
        tx_start : IN std_logic;
        d_o      : OUT std_logic;
        tx_dv_o  : OUT std_logic
    );
    end component;
    
    signal br_s : std_logic;
    
begin

        brg: brg_e
            generic map(
                clk_frequency =>12e6,
                divisor       =>10
            )
            port map(
                clk_n_i => clk_i,
                rst_n_i => rst_n_i,
                br_o    => br_s   
            );
        
        tx: UART_TX_E     
            port map(
                rst_i  => rst_n_i,
                br_i     => br_s,
                d_i      => d_i,
                tx_start => tx_start_i,
                d_o      => d_o,
                tx_dv_o  => tx_dv_o
            );


end uart_tx_top_a;
