library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity BRG_E is
    generic(
        clk_frequency : integer;
        divisor       : integer
    );
    port(
        clk_n_i : in  std_logic;
        rst_n_i : in  std_logic;
        br_o    : out std_logic
    );
end entity BRG_E;



