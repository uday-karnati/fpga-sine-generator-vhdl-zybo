----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 12/20/2023 10:50:36 PM
-- Design Name: 
-- Module Name: uart_rx_top - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity uart_rx_top is
    Port ( 
           clk_i : in STD_LOGIC;
           rst_n_i : in STD_LOGIC;
           d_i : in STD_LOGIC;
           d_o : out STD_LOGIC_VECTOR (0 to 7);
           rx_dv : out std_logic
          );
end uart_rx_top;

architecture Behavioral of uart_rx_top is
    
    component BRG_E 
    generic(
        clk_frequency : integer;
        divisor       : integer
    );
    port(
        clk_n_i : in  std_logic;
        rst_n_i : in  std_logic;
        br_o    : out std_logic
    );
    end component;
    
    component UART_RX_E 
    port(
        clk_i     : in std_logic;
        rst_i     : IN std_logic;
        br_i      : IN std_logic;
        d_i       : IN std_logic;
        d_o       : OUT std_logic_vector ( 7 downto 0 );
        rx_dv_o   : OUT std_logic
    );
    end component;
       
    signal br_s : std_logic;
begin
    
    brg: BRG_E
        generic map(
            clk_frequency =>12e6,
            divisor       =>10
        )
        port map(
            clk_n_i => clk_i,
            rst_n_i => rst_n_i,
            br_o    => br_s   
        );
    
    rx: UART_RX_E 
        port map(
            clk_i     => clk_i,
            rst_i   => rst_n_i,
            br_i      => br_s,
            d_i       => d_i,
            d_o       => d_o,
            rx_dv_o   => rx_dv
    );

end Behavioral;
