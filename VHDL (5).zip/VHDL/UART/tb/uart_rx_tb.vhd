library  ieee ;
use ieee.std_logic_1164.all;

entity uart_rx_tb_e is

end entity uart_rx_tb_e;

architecture uart_rx_tb_a of uart_rx_tb_e is 
    signal clk_s   : std_logic ;  
    signal rst_s   : std_logic ;
    signal br_s    : std_logic ; 
    signal d_s     : std_logic ; 
    signal d_o_s   : std_logic_vector (7 downto 0);
    signal rx_dv_s : std_logic ;  
    signal dum_d_s   : std_logic_vector (0 to 7) := X"67";
    
    signal rx_data_s   : integer := 0;
    
    component BRG_E 
    generic(
        clk_frequency : integer;
        divisor       : integer
    );
    port(
        clk_n_i : in  std_logic;
        rst_n_i : in  std_logic;
        br_o    : out std_logic
    );
    end component;
    
    component UART_RX_E 
    port(
        clk_i     : in std_logic;
        rst_i   : IN std_logic;
        br_i      : IN std_logic;
        d_i       : IN std_logic;
        d_o       : OUT std_logic_vector ( 7 downto 0 );
        rx_dv_o   : OUT std_logic
    );
    end component;
    
    component CLK_E
    generic(
        clk_frequency : integer
    );
    port(
        clk_o : out std_logic
    );
    end component;
    
begin
    -- clock generator entity

    u_clk_e : CLK_E
        generic map(
            clk_frequency => 12e6
        )
        port map (
            clk_o => clk_s
        );
    
    -- Baud Rate Generator entity

    u_brg_e : BRG_E
        generic map(
            clk_frequency => 12e6,
            divisor       => 16
        )
        port map (
            clk_n_i => clk_s,
            rst_n_i => rst_s,
            br_o    => br_s
        );
    
    -- UART Receiver entity

    u_uart_rx_e : UART_RX_E
        port map (
            clk_i     => clk_s,
            rst_i     => rst_s,
            br_i      => br_s,
            d_i       => d_s,
            d_o       => d_o_s,
            rx_dv_o   => rx_dv_s
        );
    
    tb : process is
    begin
        rst_s <= '0';  
        wait until br_s = '1';  -- Wait until the Brs is high
        d_s <= '1';             -- Send a start bit 
        wait until br_s = '1';
        d_s <= '0';             -- Send a stop bit
        wait until br_s = '1';
        
        for i in 0 to 7 loop    -- send data bits whn BRs is high  
          d_s <= dum_d_s(i);
          wait until br_s = '1';
        end loop ;

        d_s <= '1';
        wait until rx_dv_s = '1'; --wait till data valid 1 and reset
        rst_s <= '1';
        wait;
    end process tb;
    
  
end architecture uart_rx_tb_a;


