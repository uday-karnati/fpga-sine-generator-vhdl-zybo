library  ieee ;
use ieee.std_logic_1164.all;

entity uart_tx_tb_e is

end entity uart_tx_tb_e;

architecture uart_tx_tb_a of uart_tx_tb_e is 
    signal clk_s   : std_logic ;  
    signal rst_s   : std_logic := '0' ;
    signal br_s    : std_logic ; 
    signal d_o_s   : std_logic;  
    signal tx_dv_s : std_logic; 
    signal tx_start_s : std_logic; 
    signal dum_d_s   : std_logic_vector (0 to 7) := x"67" ; 
    --signal st_s    : std_logic_vector ( 2 downto 0); 
    
begin
     -- clock generator entity
    u_clk_e : ENTITY work.CLK_E
        generic map(
            clk_freq => 12e6
        )
        port map (
            clk_o => clk_s
        );
    
    -- Baud Rate Generator entity
    u_brg_e : ENTITY work.BRG_E
        generic map(
            clk_freq => 12e6,
            divisor       => 16
        )
        port map (
            clk_n_i => clk_s,
            rst_n_i => rst_s,
            br_o    => br_s
        );
    
    -- UART Transmitter entity
    u_uart_tx_e : ENTITY work.UART_TX_E
        port map (
            rst_n_i  => rst_s,
            br_i     => br_s,
            d_i    => dum_d_s,
            d_o      => d_o_s,
            tx_start_i => tx_start_s,
            tx_dv_o  => tx_dv_s
        );
    
    tb : process is
    begin
        tx_start_s <= '0';
        wait until br_s = '1';
        assert tx_dv_s = '1' report "Transmission Data valid..." severity warning;
        tx_start_s <= '1';
	assert d_o_s = '0' report "TX Start Data fail...." severity warning;
        wait until tx_dv_s = '1';
	assert tx_start_s = '1' report "TX Started....." severity warning;
        wait until tx_dv_s = '0';
        rst_s <= '1';
        wait;
    end process tb;
    
  
end architecture uart_tx_tb_a;


